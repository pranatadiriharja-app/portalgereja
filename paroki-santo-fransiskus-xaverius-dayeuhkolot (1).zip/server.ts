import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import mysql from "mysql2/promise";

dotenv.config();

// A safe way to handle __dirname and __filename in both ESM (dev) and CJS (production bundle)
const getDirnameAndFilename = () => {
  try {
    if (typeof import.meta !== "undefined" && import.meta.url) {
      const filename = fileURLToPath(import.meta.url);
      const dirname = path.dirname(filename);
      return { __filename: filename, __dirname: dirname };
    }
  } catch (e) {
    // Ignore error and use CJS fallback
  }
  return { 
    __filename: typeof __filename !== "undefined" ? __filename : "", 
    __dirname: typeof __dirname !== "undefined" ? __dirname : "." 
  };
};

const { __filename, __dirname } = getDirnameAndFilename();

const app = express();
const PORT = 3000;

app.use(express.json());

// Path to local database file
const DATA_DIR = path.join(__dirname, "data");
const DB_PATH = path.join(DATA_DIR, "db.json");

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial seed data
const initialData = {
  announcements: [
    {
      id: "ann-1",
      text: "Pengumuman: Pelayanan Perubahan Data Administrasi Kependudukan & Catatan Sipil diadakan pada Sabtu, 14 Maret 2026 di Gereja.",
      type: "info",
      active: true,
      createdAt: new Date().toISOString()
    }
  ],
  agenda: [
    {
      id: "ag-1",
      title: "Pelaksanaan Pelayanan Perubahan Data Administrasi Kependudukan & Catatan Sipil",
      content: "Paroki Santo Fransiskus Xaverius Dayeuhkolot bekerja sama dengan Dinas Kependudukan dan Pencatatan Sipil (Disdukcapil) Kabupaten Bandung akan menyelenggarakan pelayanan langsung administrasi kependudukan (KTP, KK, Akta Lahir, dll.) bagi jemaat gereja pada hari Sabtu, 14 Maret 2026 mulai pukul 09.00 WIB hingga selesai. Silakan membawa dokumen asli dan fotokopi berkas pendukung Anda ke aula gereja.",
      date: "2026-03-14",
      imageUrl: "https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "ag-2",
      title: "Pendaftaran Bina Iman Anak (BIA) & Bina Iman Remaja (BIR) Tahun Ajaran Baru",
      content: "Telah dibuka pendaftaran bagi anak-anak dan remaja Paroki Dayeuhkolot untuk bergabung dengan komunitas Bina Iman Anak (BIA) dan Bina Iman Remaja (BIR). Kegiatan pembinaan iman ini diadakan setiap hari Minggu setelah perayaan Ekaristi pagi. Orang tua diharapkan segera mendaftarkan putra-putrinya melalui e-formulir atau langsung ke koordinator BIA/BIR di pendopo gereja.",
      date: "2026-07-12",
      imageUrl: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "ag-3",
      title: "Kerja Bakti Sosial Lingkungan dan Kebersihan Area Kompleks Gereja",
      content: "Dalam rangka menyambut pesta pelindung Paroki Santo Fransiskus Xaverius, Dewan Pastoral Paroki mengundang perwakilan umat dari seluruh Lingkungan untuk berpartisipasi dalam kegiatan kerja bakti kebersihan dan penghijauan area gereja. Harap membawa peralatan kebersihan masing-masing. Kegiatan dimulai pukul 08.00 WIB.",
      date: "2026-07-19",
      imageUrl: "https://images.unsplash.com/photo-1559027615-cd4451a9962f?auto=format&fit=crop&w=800&q=80"
    }
  ],
  dpp: [
    {
      id: "dpp-1",
      role: "KETUA UMUM",
      category: "pimpinan",
      name: "R.D. Stefanus Tanto Agustiana",
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "dpp-2",
      role: "KETUA",
      category: "pimpinan",
      name: "R.D. Antonius Jonmedi Tarigan",
      imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "dpp-3",
      role: "WAKIL KETUA DPP 1",
      category: "wakil",
      name: "Drs. Ignasius Budi Prasetyo",
      imageUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "dpp-4",
      role: "WAKIL KETUA DPP 2",
      category: "wakil",
      name: "Maria Clara Sutjiati",
      imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "dpp-5",
      role: "SEKRETARIS 1",
      category: "sekretaris",
      name: "Yohanes Herryanto",
      imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "dpp-6",
      role: "SEKRETARIS 2",
      category: "sekretaris",
      name: "Anastasia Maria",
      imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"
    },
    {
      id: "dpp-7",
      role: "BENDAHARA 1",
      category: "bendahara",
      name: "Elizabeth Setiawati",
      imageUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80"
    }
  ],
  lingkungan: [
    {
      id: "l-1",
      name: "Lingkungan Santo Fransiskus Asisi",
      leader: "Yulius Sukardi",
      phone: "081234567890"
    },
    {
      id: "l-2",
      name: "Lingkungan Santa Maria Regina",
      leader: "Robertus Triadi",
      phone: "081398765432"
    },
    {
      id: "l-3",
      name: "Lingkungan Santo Yohanes Pembaptis",
      leader: "Fransiska Endah",
      phone: "085711223344"
    },
    {
      id: "l-4",
      name: "Lingkungan Santo Petrus",
      leader: "Albertus Sugiarto",
      phone: "082144556677"
    },
    {
      id: "l-5",
      name: "Lingkungan Santa Teresa",
      leader: "Agnes Widya",
      phone: "081933445566"
    },
    {
      id: "l-6",
      name: "Lingkungan Santo Yosef",
      leader: "Benediktus Hartono",
      phone: "081122334455"
    }
  ],
  sacramentRegistrations: [],
  suggestions: []
};

// Database read helper
function readDB() {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(initialData, null, 2), "utf8");
      return initialData;
    }
    const data = fs.readFileSync(DB_PATH, "utf8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Error reading database:", error);
    return initialData;
  }
}

// Database write helper
function writeDB(data: any) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    console.error("Error writing database:", error);
  }
}

// --- MySQL Connection and Database initialization ---

let useMySql = false;
let pool: mysql.Pool | null = null;

async function createTables() {
  if (!pool) return;
  
  await pool.query(`
    CREATE TABLE IF NOT EXISTS announcements (
      id VARCHAR(50) PRIMARY KEY,
      text TEXT NOT NULL,
      type VARCHAR(50) DEFAULT 'info',
      active BOOLEAN DEFAULT TRUE,
      createdAt VARCHAR(100)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS agenda (
      id VARCHAR(50) PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      content TEXT NOT NULL,
      date VARCHAR(50) NOT NULL,
      imageUrl TEXT
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS dpp (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      role VARCHAR(255) NOT NULL,
      category VARCHAR(50) NOT NULL,
      imageUrl TEXT
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lingkungan (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      leader VARCHAR(255) NOT NULL,
      phone VARCHAR(50) NOT NULL
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS sacrament_registrations (
      id VARCHAR(50) PRIMARY KEY,
      fullName VARCHAR(255) NOT NULL,
      phone VARCHAR(50) NOT NULL,
      email VARCHAR(255) NOT NULL,
      sacramentType VARCHAR(100) NOT NULL,
      birthPlaceDate VARCHAR(255) NOT NULL,
      address TEXT NOT NULL,
      details TEXT,
      status VARCHAR(50) DEFAULT 'Pending',
      createdAt VARCHAR(100)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS suggestions (
      id VARCHAR(50) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      createdAt VARCHAR(100)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS dokumentasi (
      id VARCHAR(50) PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      date VARCHAR(50) NOT NULL,
      googlePhotosUrl TEXT,
      imageUrl TEXT
    )
  `);
}

async function seedMySql() {
  if (!pool) return;
  
  // Seed announcements
  const [annRows] = await pool.query<any[]>("SELECT COUNT(*) as count FROM announcements");
  if ((annRows[0]?.count || 0) === 0) {
    for (const ann of initialData.announcements) {
      await pool.query(
        "INSERT INTO announcements (id, text, type, active, createdAt) VALUES (?, ?, ?, ?, ?)",
        [ann.id, ann.text, ann.type, ann.active ? 1 : 0, ann.createdAt]
      );
    }
  }

  // Seed agenda
  const [agendaRows] = await pool.query<any[]>("SELECT COUNT(*) as count FROM agenda");
  if ((agendaRows[0]?.count || 0) === 0) {
    for (const item of initialData.agenda) {
      await pool.query(
        "INSERT INTO agenda (id, title, content, date, imageUrl) VALUES (?, ?, ?, ?, ?)",
        [item.id, item.title, item.content, item.date, item.imageUrl]
      );
    }
  }

  // Seed dpp
  const [dppRows] = await pool.query<any[]>("SELECT COUNT(*) as count FROM dpp");
  if ((dppRows[0]?.count || 0) === 0) {
    for (const item of initialData.dpp) {
      await pool.query(
        "INSERT INTO dpp (id, name, role, category, imageUrl) VALUES (?, ?, ?, ?, ?)",
        [item.id, item.name, item.role, item.category, item.imageUrl]
      );
    }
  }

  // Seed lingkungan
  const [lingRows] = await pool.query<any[]>("SELECT COUNT(*) as count FROM lingkungan");
  if ((lingRows[0]?.count || 0) === 0) {
    for (const item of initialData.lingkungan) {
      await pool.query(
        "INSERT INTO lingkungan (id, name, leader, phone) VALUES (?, ?, ?, ?)",
        [item.id, item.name, item.leader, item.phone]
      );
    }
  }
}

async function initDb() {
  const mysqlHost = process.env.DB_HOST || process.env.MYSQL_HOST;
  const mysqlUser = process.env.DB_USER || process.env.MYSQL_USER;
  const mysqlPassword = process.env.DB_PASSWORD || process.env.MYSQL_PASSWORD;
  const mysqlDatabase = process.env.DB_DATABASE || process.env.MYSQL_DATABASE;
  const mysqlPort = process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306;
  const mysqlUrl = process.env.MYSQL_URL;

  if (mysqlUrl || (mysqlHost && mysqlUser && mysqlDatabase)) {
    try {
      console.log("MySQL configuration found. Connecting to MySQL...");
      if (mysqlUrl) {
        pool = mysql.createPool(mysqlUrl);
      } else {
        pool = mysql.createPool({
          host: mysqlHost,
          user: mysqlUser,
          password: mysqlPassword,
          database: mysqlDatabase,
          port: mysqlPort,
          waitForConnections: true,
          connectionLimit: 10,
          queueLimit: 0,
          ssl: process.env.DB_SSL === "true" ? { rejectUnauthorized: false } : undefined
        });
      }
      
      const connection = await pool.getConnection();
      console.log("MySQL connection successful!");
      connection.release();
      
      useMySql = true;
      
      await createTables();
      await seedMySql();
    } catch (err) {
      console.error("Failed to connect to MySQL database:", err);
      console.log("Falling back to local db.json database.");
      useMySql = false;
    }
  } else {
    console.log("No MySQL environment variables found. Using local db.json database.");
    useMySql = false;
  }
}

// Database service layer with fallback to file database
const dbService = {
  getAnnouncements: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM announcements ORDER BY createdAt DESC");
      return rows.map(r => ({ ...r, active: !!r.active }));
    } else {
      const local = readDB();
      return local.announcements || [];
    }
  },
  
  addAnnouncement: async (text: string, type: string, active: boolean) => {
    const id = "ann-" + Date.now();
    const createdAt = new Date().toISOString();
    
    if (useMySql && pool) {
      await pool.query("UPDATE announcements SET active = 0");
      await pool.query(
        "INSERT INTO announcements (id, text, type, active, createdAt) VALUES (?, ?, ?, ?, ?)",
        [id, text, type || "info", active ? 1 : 0, createdAt]
      );
      return { id, text, type, active, createdAt };
    } else {
      const local = readDB();
      local.announcements = (local.announcements || []).map((a: any) => ({ ...a, active: false }));
      const newAnn = { id, text, type, active, createdAt };
      local.announcements.unshift(newAnn);
      writeDB(local);
      return newAnn;
    }
  },

  getAgenda: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM agenda ORDER BY date ASC");
      return rows;
    } else {
      const local = readDB();
      return local.agenda || [];
    }
  },

  addAgenda: async (title: string, content: string, date: string, imageUrl: string) => {
    const id = "ag-" + Date.now();
    const img = imageUrl || "https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80";
    
    if (useMySql && pool) {
      await pool.query(
        "INSERT INTO agenda (id, title, content, date, imageUrl) VALUES (?, ?, ?, ?, ?)",
        [id, title, content, date, img]
      );
      return { id, title, content, date, imageUrl: img };
    } else {
      const local = readDB();
      const newItem = { id, title, content, date, imageUrl: img };
      local.agenda = local.agenda || [];
      local.agenda.unshift(newItem);
      writeDB(local);
      return newItem;
    }
  },

  updateAgenda: async (id: string, updates: any) => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM agenda WHERE id = ?", [id]);
      if (rows.length === 0) return null;
      const current = rows[0];
      
      const title = updates.title !== undefined ? updates.title : current.title;
      const content = updates.content !== undefined ? updates.content : current.content;
      const date = updates.date !== undefined ? updates.date : current.date;
      const imageUrl = updates.imageUrl !== undefined ? updates.imageUrl : current.imageUrl;
      
      await pool.query(
        "UPDATE agenda SET title = ?, content = ?, date = ?, imageUrl = ? WHERE id = ?",
        [title, content, date, imageUrl, id]
      );
      return { success: true };
    } else {
      const local = readDB();
      local.agenda = (local.agenda || []).map((item: any) => {
        if (item.id === id) {
          return {
            ...item,
            title: updates.title !== undefined ? updates.title : item.title,
            content: updates.content !== undefined ? updates.content : item.content,
            date: updates.date !== undefined ? updates.date : item.date,
            imageUrl: updates.imageUrl !== undefined ? updates.imageUrl : item.imageUrl
          };
        }
        return item;
      });
      writeDB(local);
      return { success: true, agenda: local.agenda };
    }
  },

  deleteAgenda: async (id: string) => {
    if (useMySql && pool) {
      await pool.query("DELETE FROM agenda WHERE id = ?", [id]);
      return { success: true };
    } else {
      const local = readDB();
      local.agenda = (local.agenda || []).filter((item: any) => item.id !== id);
      writeDB(local);
      return { success: true };
    }
  },

  getDPP: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM dpp");
      return rows;
    } else {
      const local = readDB();
      return local.dpp || [];
    }
  },

  addDPP: async (name: string, role: string, category: string, imageUrl: string) => {
    const id = "dpp-" + Date.now();
    const cat = category || "seksi";
    const img = imageUrl || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80";
    
    if (useMySql && pool) {
      await pool.query(
        "INSERT INTO dpp (id, name, role, category, imageUrl) VALUES (?, ?, ?, ?, ?)",
        [id, name, role, cat, img]
      );
      return { id, name, role, category: cat, imageUrl: img };
    } else {
      const local = readDB();
      const newItem = { id, name, role, category: cat, imageUrl: img };
      local.dpp = local.dpp || [];
      local.dpp.push(newItem);
      writeDB(local);
      return newItem;
    }
  },

  updateDPP: async (id: string, updates: any) => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM dpp WHERE id = ?", [id]);
      if (rows.length === 0) return null;
      const current = rows[0];
      
      const name = updates.name !== undefined ? updates.name : current.name;
      const role = updates.role !== undefined ? updates.role : current.role;
      const category = updates.category !== undefined ? updates.category : current.category;
      const imageUrl = updates.imageUrl !== undefined ? updates.imageUrl : current.imageUrl;
      
      await pool.query(
        "UPDATE dpp SET name = ?, role = ?, category = ?, imageUrl = ? WHERE id = ?",
        [name, role, category, imageUrl, id]
      );
      return { success: true };
    } else {
      const local = readDB();
      local.dpp = (local.dpp || []).map((item: any) => {
        if (item.id === id) {
          return {
            ...item,
            name: updates.name !== undefined ? updates.name : item.name,
            role: updates.role !== undefined ? updates.role : item.role,
            category: updates.category !== undefined ? updates.category : item.category,
            imageUrl: updates.imageUrl !== undefined ? updates.imageUrl : item.imageUrl
          };
        }
        return item;
      });
      writeDB(local);
      return { success: true, dpp: local.dpp };
    }
  },

  deleteDPP: async (id: string) => {
    if (useMySql && pool) {
      await pool.query("DELETE FROM dpp WHERE id = ?", [id]);
      return { success: true };
    } else {
      const local = readDB();
      local.dpp = (local.dpp || []).filter((item: any) => item.id !== id);
      writeDB(local);
      return { success: true };
    }
  },

  getLingkungan: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM lingkungan");
      return rows;
    } else {
      const local = readDB();
      return local.lingkungan || [];
    }
  },

  updateLingkungan: async (id: string, updates: any) => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM lingkungan WHERE id = ?", [id]);
      if (rows.length === 0) return null;
      const current = rows[0];
      
      const name = updates.name !== undefined ? updates.name : current.name;
      const leader = updates.leader !== undefined ? updates.leader : current.leader;
      const phone = updates.phone !== undefined ? updates.phone : current.phone;
      
      await pool.query(
        "UPDATE lingkungan SET name = ?, leader = ?, phone = ? WHERE id = ?",
        [name, leader, phone, id]
      );
      return { success: true };
    } else {
      const local = readDB();
      local.lingkungan = (local.lingkungan || []).map((item: any) => {
        if (item.id === id) {
          return {
            ...item,
            name: updates.name !== undefined ? updates.name : item.name,
            leader: updates.leader !== undefined ? updates.leader : item.leader,
            phone: updates.phone !== undefined ? updates.phone : item.phone
          };
        }
        return item;
      });
      writeDB(local);
      return { success: true, lingkungan: local.lingkungan };
    }
  },

  getSacramentRegistrations: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM sacrament_registrations ORDER BY createdAt DESC");
      return rows;
    } else {
      const local = readDB();
      return local.sacramentRegistrations || [];
    }
  },

  addSacramentRegistration: async (data: any) => {
    const id = "reg-" + Date.now();
    const createdAt = new Date().toISOString();
    const status = "Pending";
    const details = data.details || "";
    
    if (useMySql && pool) {
      await pool.query(
        "INSERT INTO sacrament_registrations (id, fullName, phone, email, sacramentType, birthPlaceDate, address, details, status, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [id, data.fullName, data.phone, data.email, data.sacramentType, data.birthPlaceDate, data.address, details, status, createdAt]
      );
      return { id, ...data, details, status, createdAt };
    } else {
      const local = readDB();
      const newRegistration = { id, ...data, details, status, createdAt };
      local.sacramentRegistrations = local.sacramentRegistrations || [];
      local.sacramentRegistrations.unshift(newRegistration);
      writeDB(local);
      return newRegistration;
    }
  },

  updateSacramentRegistrationStatus: async (id: string, status: string) => {
    if (useMySql && pool) {
      await pool.query("UPDATE sacrament_registrations SET status = ? WHERE id = ?", [status, id]);
      return { success: true };
    } else {
      const local = readDB();
      local.sacramentRegistrations = (local.sacramentRegistrations || []).map((item: any) => {
        if (item.id === id) {
          return { ...item, status };
        }
        return item;
      });
      writeDB(local);
      return { success: true, sacramentRegistrations: local.sacramentRegistrations };
    }
  },

  getSuggestions: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM suggestions ORDER BY createdAt DESC");
      return rows;
    } else {
      const local = readDB();
      return local.suggestions || [];
    }
  },

  addSuggestion: async (name: string, email: string, message: string) => {
    const id = "sug-" + Date.now();
    const createdAt = new Date().toISOString();
    
    if (useMySql && pool) {
      await pool.query(
        "INSERT INTO suggestions (id, name, email, message, createdAt) VALUES (?, ?, ?, ?, ?)",
        [id, name, email, message, createdAt]
      );
      return { id, name, email, message, createdAt };
    } else {
      const local = readDB();
      const newSuggestion = { id, name, email, message, createdAt };
      local.suggestions = local.suggestions || [];
      local.suggestions.unshift(newSuggestion);
      writeDB(local);
      return newSuggestion;
    }
  },

  getDokumentasi: async () => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM dokumentasi ORDER BY date DESC");
      return rows;
    } else {
      const local = readDB();
      return local.dokumentasi || [];
    }
  },

  addDokumentasi: async (title: string, date: string, googlePhotosUrl: string, imageUrl: string) => {
    const id = "doc-" + Date.now();
    const img = imageUrl || "https://images.unsplash.com/photo-1548625361-155deee22154?auto=format&fit=crop&w=400&q=80";
    
    if (useMySql && pool) {
      await pool.query(
        "INSERT INTO dokumentasi (id, title, date, googlePhotosUrl, imageUrl) VALUES (?, ?, ?, ?, ?)",
        [id, title, date, googlePhotosUrl || "", img]
      );
      return { id, title, date, googlePhotosUrl, imageUrl: img };
    } else {
      const local = readDB();
      const newItem = { id, title, date, googlePhotosUrl, imageUrl: img };
      local.dokumentasi = local.dokumentasi || [];
      local.dokumentasi.push(newItem);
      writeDB(local);
      return newItem;
    }
  },

  updateDokumentasi: async (id: string, updates: any) => {
    if (useMySql && pool) {
      const [rows] = await pool.query<any[]>("SELECT * FROM dokumentasi WHERE id = ?", [id]);
      if (rows.length === 0) return null;
      const current = rows[0];
      
      const title = updates.title !== undefined ? updates.title : current.title;
      const date = updates.date !== undefined ? updates.date : current.date;
      const googlePhotosUrl = updates.googlePhotosUrl !== undefined ? updates.googlePhotosUrl : current.googlePhotosUrl;
      const imageUrl = updates.imageUrl !== undefined ? updates.imageUrl : current.imageUrl;
      
      await pool.query(
        "UPDATE dokumentasi SET title = ?, date = ?, googlePhotosUrl = ?, imageUrl = ? WHERE id = ?",
        [title, date, googlePhotosUrl, imageUrl, id]
      );
      return { success: true };
    } else {
      const local = readDB();
      local.dokumentasi = (local.dokumentasi || []).map((item: any) => {
        if (item.id === id) {
          return {
            ...item,
            title: updates.title !== undefined ? updates.title : item.title,
            date: updates.date !== undefined ? updates.date : item.date,
            googlePhotosUrl: updates.googlePhotosUrl !== undefined ? updates.googlePhotosUrl : item.googlePhotosUrl,
            imageUrl: updates.imageUrl !== undefined ? updates.imageUrl : item.imageUrl
          };
        }
        return item;
      });
      writeDB(local);
      return { success: true, dokumentasi: local.dokumentasi };
    }
  },

  deleteDokumentasi: async (id: string) => {
    if (useMySql && pool) {
      await pool.query("DELETE FROM dokumentasi WHERE id = ?", [id]);
      return { success: true };
    } else {
      const local = readDB();
      local.dokumentasi = (local.dokumentasi || []).filter((item: any) => item.id !== id);
      writeDB(local);
      return { success: true };
    }
  }
};

// --- API ENDPOINTS ---

// Admin login verification
app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "admin321") {
    res.json({ success: true, token: "sfxd-auth-token-2026-secret-superadmin", role: "superadmin" });
  } else if (username === "admin" && password === "admin111") {
    res.json({ success: true, token: "sfxd-auth-token-2026-secret-sekretariat", role: "sekretariat" });
  } else {
    res.status(401).json({ success: false, message: "Username atau Password salah" });
  }
});

// GET active announcements
app.get("/api/announcements", async (req, res) => {
  try {
    const list = await dbService.getAnnouncements();
    const activeAnnouncements = list.filter((a: any) => a.active);
    res.json(activeAnnouncements);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch announcements" });
  }
});

// POST update announcement (admin)
app.post("/api/admin/announcements", async (req, res) => {
  const { text, type, active } = req.body;
  try {
    const newAnn = await dbService.addAnnouncement(text, type, active);
    res.json(newAnn);
  } catch (error) {
    res.status(500).json({ error: "Failed to add announcement" });
  }
});

// GET all agenda items
app.get("/api/agenda", async (req, res) => {
  try {
    const list = await dbService.getAgenda();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch agenda" });
  }
});

// POST add agenda item (admin)
app.post("/api/admin/agenda", async (req, res) => {
  const { title, content, date, imageUrl } = req.body;
  try {
    const newItem = await dbService.addAgenda(title, content, date, imageUrl);
    res.json(newItem);
  } catch (error) {
    res.status(500).json({ error: "Failed to add agenda" });
  }
});

// PUT update agenda item (admin)
app.put("/api/admin/agenda/:id", async (req, res) => {
  const { id } = req.params;
  const { title, content, date, imageUrl } = req.body;
  try {
    const result = await dbService.updateAgenda(id, { title, content, date, imageUrl });
    if (!result) return res.status(404).json({ error: "Agenda not found" });
    const list = await dbService.getAgenda();
    res.json({ success: true, agenda: list });
  } catch (error) {
    res.status(500).json({ error: "Failed to update agenda" });
  }
});

// DELETE agenda item (admin)
app.delete("/api/admin/agenda/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await dbService.deleteAgenda(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete agenda" });
  }
});

// GET all DPP members
app.get("/api/dpp", async (req, res) => {
  try {
    const list = await dbService.getDPP();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch DPP" });
  }
});

// POST add DPP member (admin)
app.post("/api/admin/dpp", async (req, res) => {
  const { name, role, category, imageUrl } = req.body;
  try {
    const newItem = await dbService.addDPP(name, role, category, imageUrl);
    res.json(newItem);
  } catch (error) {
    res.status(500).json({ error: "Failed to add DPP member" });
  }
});

// PUT update DPP member (admin)
app.put("/api/admin/dpp/:id", async (req, res) => {
  const { id } = req.params;
  const { name, role, category, imageUrl } = req.body;
  try {
    const result = await dbService.updateDPP(id, { name, role, category, imageUrl });
    if (!result) return res.status(404).json({ error: "DPP member not found" });
    const list = await dbService.getDPP();
    res.json({ success: true, dpp: list });
  } catch (error) {
    res.status(500).json({ error: "Failed to update DPP member" });
  }
});

// DELETE DPP member (admin)
app.delete("/api/admin/dpp/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await dbService.deleteDPP(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete DPP member" });
  }
});

// GET all environments
app.get("/api/lingkungan", async (req, res) => {
  try {
    const list = await dbService.getLingkungan();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch lingkungan" });
  }
});

// PUT update environment (admin)
app.put("/api/admin/lingkungan/:id", async (req, res) => {
  const { id } = req.params;
  const { name, leader, phone } = req.body;
  try {
    const result = await dbService.updateLingkungan(id, { name, leader, phone });
    if (!result) return res.status(404).json({ error: "Lingkungan not found" });
    const list = await dbService.getLingkungan();
    res.json({ success: true, lingkungan: list });
  } catch (error) {
    res.status(500).json({ error: "Failed to update lingkungan" });
  }
});

// GET sacrament registrations (admin)
app.get("/api/sacrament-registrations", async (req, res) => {
  try {
    const list = await dbService.getSacramentRegistrations();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch sacrament registrations" });
  }
});

// POST create sacrament registration (public)
app.post("/api/sacrament-registrations", async (req, res) => {
  const { fullName, phone, email, sacramentType, birthPlaceDate, address, details } = req.body;
  try {
    const newReg = await dbService.addSacramentRegistration({ fullName, phone, email, sacramentType, birthPlaceDate, address, details });
    res.json({ success: true, data: newReg });
  } catch (error) {
    res.status(500).json({ error: "Failed to submit registration" });
  }
});

// PUT update sacrament registration status (admin)
app.put("/api/admin/sacrament-registrations/:id", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  try {
    const result = await dbService.updateSacramentRegistrationStatus(id, status);
    if (!result) return res.status(404).json({ error: "Registration not found" });
    const list = await dbService.getSacramentRegistrations();
    res.json({ success: true, data: list });
  } catch (error) {
    res.status(500).json({ error: "Failed to update registration status" });
  }
});

// GET all suggestions (admin)
app.get("/api/suggestions", async (req, res) => {
  try {
    const list = await dbService.getSuggestions();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch suggestions" });
  }
});

// POST submit a suggestion (public)
app.post("/api/suggestions", async (req, res) => {
  const { name, email, message } = req.body;
  try {
    const newSuggestion = await dbService.addSuggestion(name, email, message);
    
    // OPTIONAL: Google Sheets API Integration
    const webhookUrl = process.env.GOOGLE_SHEETS_WEBHOOK_URL;
    if (webhookUrl) {
      try {
        console.log("Sending suggestion to Google Sheets:", newSuggestion);
        await fetch(webhookUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sheet: "Kotak Saran",
            data: {
              Tanggal: new Date(newSuggestion.createdAt).toLocaleString("id-ID"),
              Nama: newSuggestion.name,
              Email: newSuggestion.email,
              Pesan: newSuggestion.message
            }
          })
        });
      } catch (err) {
        console.error("Failed to forward suggestion to Google Sheets webhook:", err);
      }
    } else {
      console.log("Google Sheets webhook URL is not configured. Saved suggestion locally.");
    }
    
    res.json({ success: true, data: newSuggestion });
  } catch (error) {
    res.status(500).json({ error: "Failed to submit suggestion" });
  }
});

// GET all documentation items
app.get("/api/dokumentasi", async (req, res) => {
  try {
    const list = await dbService.getDokumentasi();
    res.json(list);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch documentation" });
  }
});

// POST add a new documentation item (admin)
app.post("/api/admin/dokumentasi", async (req, res) => {
  const { title, date, googlePhotosUrl, imageUrl } = req.body;
  try {
    const newItem = await dbService.addDokumentasi(title, date, googlePhotosUrl, imageUrl);
    res.json(newItem);
  } catch (error) {
    res.status(500).json({ error: "Failed to add documentation item" });
  }
});

// PUT update documentation item (admin)
app.put("/api/admin/dokumentasi/:id", async (req, res) => {
  const { id } = req.params;
  const { title, date, googlePhotosUrl, imageUrl } = req.body;
  try {
    const result = await dbService.updateDokumentasi(id, { title, date, googlePhotosUrl, imageUrl });
    if (!result) return res.status(404).json({ error: "Documentation item not found" });
    const list = await dbService.getDokumentasi();
    res.json({ success: true, dokumentasi: list });
  } catch (error) {
    res.status(500).json({ error: "Failed to update documentation item" });
  }
});

// DELETE documentation item (admin)
app.delete("/api/admin/dokumentasi/:id", async (req, res) => {
  const { id } = req.params;
  try {
    await dbService.deleteDokumentasi(id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete documentation item" });
  }
});

// Vite Middleware & SPA serving
export async function startServer() {
  await initDb();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

if (process.env.VERCEL !== "1" && process.env.NODE_ENV !== "test") {
  startServer();
}

export { app, initDb };

